==============================================================
Compass Host Installation Notes and Technical Information
==============================================================

  How To Install --  Run the Setup program provided on the CD by double clicking
                     its icon using the left mouse button. Setup will create
                     a directory called CompassHost in the root directory of
                     the C drive. The Compasshost program will be copied into
                     this directory along with a directory called ActiveX that 
                     contains all the required OCXes needed to run the program.
                     Once this has been done, Setup will attempt to register the
                     ActiveX components with Windows.

                     After sucessful registration of the components, reboot the
                     computer for best operating results.

                     CompassHost is now ready for use. To activate the CompassHost
                     program, double click on the CompassHost icon using the left
                     mouse button.

		     Note: If a previous version of CompassHost was already sucessfully 
                     loaded on the computer, then it is not necessary to rerun the
                     Setup batch program to install a new version of the CompassHost 
                     executable. Just copy the new CompassHost.exe file out of the
                     Compasshost directory on the CD and place it into the Compasshost
                     directory on the C drive. 

		     Note: Installation may fail if the MS-DOS environment space is
		     not large enough. To increase the size of the DOS environment
		     space, right click on the "Setup.bat" icon, select 
		     "MS-DOS Prompt Properties," select "MEMORY" and then select 
		     from the "Initial Environment" menu a suffieciently large 
		     environment space value. Close the properties window, and then
		     run the Setup.bat file.