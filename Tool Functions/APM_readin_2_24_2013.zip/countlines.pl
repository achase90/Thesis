while (<>) {};
print $.,"\n";
